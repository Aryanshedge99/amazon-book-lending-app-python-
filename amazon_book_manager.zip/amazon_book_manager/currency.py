"""Rupee formatting helpers (Indian digit grouping: 12,34,567.00)."""

RUPEE = "\u20b9"  # ₹


def format_inr(value, decimals: int = 2) -> str:
    """Format a number as rupees with lakh/crore style grouping.

    >>> format_inr(1234567.5)
    '₹12,34,567.50'
    >>> format_inr(999, 0)
    '₹999'
    """
    try:
        value = float(value or 0)
    except (TypeError, ValueError):
        value = 0.0
    sign = "-" if value < 0 else ""
    whole, _, frac = f"{abs(value):.{decimals}f}".partition(".")
    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups + [tail])
    out = f"{RUPEE}{whole}"
    if decimals:
        out += f".{frac}"
    return sign + out


def compact_inr(value) -> str:
    """Short form for chart axes: ₹850, ₹1.5K, ₹2.4L, ₹1.2Cr."""
    value = float(value or 0)
    a = abs(value)
    if a >= 1e7:
        s = f"{value / 1e7:.1f}".rstrip("0").rstrip(".") + "Cr"
    elif a >= 1e5:
        s = f"{value / 1e5:.1f}".rstrip("0").rstrip(".") + "L"
    elif a >= 1e3:
        s = f"{value / 1e3:.1f}".rstrip("0").rstrip(".") + "K"
    else:
        s = f"{value:.0f}"
    return f"{RUPEE}{s}"
