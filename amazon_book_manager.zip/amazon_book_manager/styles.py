"""Modern dark theme for the Bookshelf app (single QSS string).

Tweak the colour tokens below to re-theme the whole app in one place.
"""

BG = "#14141C"
SURFACE = "#1D1D28"
SURFACE_ALT = "#22222F"
SIDEBAR = "#171720"
BORDER = "#2A2A3A"
TEXT = "#E8E8F2"
MUTED = "#8A8AA0"
ACCENT = "#7C6CF0"
ACCENT_HOVER = "#8E80F5"
DANGER = "#FF7A7A"

STYLE_SHEET = f"""
* {{
    font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', 'Arial', sans-serif;
    color: {TEXT};
}}

QMainWindow, QWidget {{ background-color: {BG}; }}
QLabel {{ background: transparent; }}
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}

QToolTip {{
    background-color: #2A2A3D;
    color: #FFFFFF;
    border: 1px solid {ACCENT};
    border-radius: 6px;
    padding: 6px 8px;
    font-size: 12px;
}}

/* ---------- Sidebar ---------- */
#sidebar {{
    background-color: {SIDEBAR};
    border-right: 1px solid #22222E;
}}
#brand {{ font-size: 19px; font-weight: 700; color: #FFFFFF; }}
#brandSub {{ font-size: 11px; color: {MUTED}; }}
#sidebarFooter {{ color: #55556B; font-size: 11px; }}
#sidebarSection {{ color: #55556B; font-size: 10px; font-weight: 700; }}

#brandIcon {{ font-size: 24px; background: transparent; }}
#navContainer, #sidebarInner {{ background: transparent; }}
/* sliding active-tab pill (moved by QPropertyAnimation in main_window.py) */
#navPill {{
    background-color: {ACCENT};
    border: none;
    border-radius: 10px;
}}

/* ---------- Page headings ---------- */
#pageTitle {{ font-size: 26px; font-weight: 700; color: #FFFFFF; }}
#pageSubtitle {{ font-size: 13px; color: {MUTED}; }}

/* ---------- Cards ---------- */
/* #statCard and #card are custom-painted (hover-animated) in ui/widgets.py */

#statValue {{ font-size: 28px; font-weight: 700; color: #FFFFFF; }}
#statTitle {{ font-size: 12px; color: {MUTED}; font-weight: 600; }}
#statHint {{ font-size: 11px; color: #6E6E86; }}

#cardTitle {{ font-size: 15px; font-weight: 700; color: #F2F2FA; }}
#cardSubtitle {{ font-size: 12px; color: {MUTED}; }}
#resultCount {{ font-size: 12px; color: {MUTED}; }}
#emptyState {{ font-size: 13px; color: {MUTED}; }}

/* ---------- Inputs ---------- */
QLineEdit, QComboBox, QDateEdit, QDoubleSpinBox, QTextEdit {{
    background-color: {SURFACE};
    border: 1px solid #303044;
    border-radius: 10px;
    padding: 8px 12px;
    font-size: 13px;
    color: {TEXT};
    selection-background-color: {ACCENT};
}}
QLineEdit:hover, QComboBox:hover, QDateEdit:hover, QDoubleSpinBox:hover {{ border: 1px solid #40405A; }}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QDoubleSpinBox:focus, QTextEdit:focus {{
    border: 1px solid {ACCENT};
}}
QComboBox::drop-down, QDateEdit::drop-down {{ border: none; width: 26px; }}
QComboBox QAbstractItemView {{
    background-color: {SURFACE};
    border: 1px solid #303044;
    selection-background-color: {ACCENT};
    outline: none;
    padding: 4px;
}}
QCalendarWidget QWidget {{ background-color: {SURFACE}; }}

/* ---------- Buttons ---------- */
QPushButton {{
    background-color: {SURFACE_ALT};
    border: 1px solid #303044;
    border-radius: 10px;
    padding: 9px 18px;
    font-size: 13px;
}}
QPushButton:hover {{ background-color: #2B2B3C; border: 1px solid #40405A; }}
QPushButton:pressed {{ background-color: #1F1F2A; }}
QPushButton:disabled {{ color: #5A5A70; }}

QPushButton#primaryButton {{
    background-color: {ACCENT};
    border: none;
    color: #FFFFFF;
    font-weight: 600;
}}
QPushButton#primaryButton:hover {{ background-color: {ACCENT_HOVER}; }}

QPushButton#dangerButton {{
    background-color: transparent;
    border: 1px solid {DANGER};
    color: {DANGER};
}}
QPushButton#dangerButton:hover {{ background-color: #2C1A1E; }}

/* ---------- Tables ---------- */
QTableWidget {{
    background-color: transparent;
    alternate-background-color: #20202C;
    border: none;
    gridline-color: transparent;
    font-size: 13px;
    selection-background-color: #2E2A5A;
    selection-color: #FFFFFF;
    outline: none;
}}
QHeaderView {{ background: transparent; }}
QHeaderView::section {{
    background-color: transparent;
    color: {MUTED};
    padding: 10px 8px;
    border: none;
    border-bottom: 1px solid {BORDER};
    font-size: 11px;
    font-weight: 700;
}}
QTableWidget::item {{ padding: 4px 8px; border: none; }}
QTableWidget::item:selected {{ background-color: #2E2A5A; color: #FFFFFF; }}
QTableCornerButton::section {{ background: transparent; border: none; }}

/* ---------- Dialogs / message boxes ---------- */
QDialog {{ background-color: #191922; }}
QLabel#dialogTitle {{ font-size: 18px; font-weight: 700; color: #FFFFFF; }}
QMessageBox {{ background-color: #191922; }}
QMessageBox QLabel {{ color: {TEXT}; font-size: 13px; }}
QFormLayout QLabel {{ color: #B4B4C8; font-size: 12.5px; }}

/* ---------- Scrollbars ---------- */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: #33334A; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: #4A4A6A; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0px; }}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; }}

QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: #33334A; border-radius: 4px; min-width: 30px; }}
QScrollBar::handle:horizontal:hover {{ background: #4A4A6A; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0px; }}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{ background: transparent; }}
"""
