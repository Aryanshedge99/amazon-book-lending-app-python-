"""
Bookshelf — Amazon Book Collection & Personal Lending Register
Entry point for the PySide6 desktop application.

Run with:  python main.py
"""

import sys

from PySide6.QtWidgets import QApplication

from database import Database
from styles import STYLE_SHEET
from ui.main_window import MainWindow


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE_SHEET)

    db = Database()
    window = MainWindow(db)
    window.show()

    exit_code = app.exec()
    db.close()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
