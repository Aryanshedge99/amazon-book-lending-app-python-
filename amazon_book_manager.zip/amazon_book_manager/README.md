# 📘 Bookshelf — Amazon Book Collection & Personal Lending Register

A minimalist, modern desktop app to track your personal book collection and
keep a register of who you've lent books to. Built with **PySide6**, a local
**SQLite** database, and **Matplotlib** charts.

## Features

**Dashboard**
- Total books, currently available, lent to others, overdue books
- Books-by-genre overview chart

**Book Collection**
- Add / edit / delete books
- Search by title, author, ISBN, or publisher
- Filter by genre and availability
- Fields: ISBN, author, genre, publisher, purchase date/price, Amazon link, reading status
- One-click open of a book's Amazon link

**Personal Lending Register**
- Record: borrower name, book, date lent, expected/actual return date, status, notes
- "Mark Returned" action, automatic overdue detection
- Search and status filters

**Analytics**
- Summary strip: total spent, average price, books completed, most-lent book
- Books by genre (donut with a legend showing count and %)
- Most frequently lent books (ranked bars with values)
- Monthly purchases (columns, empty months filled in)
- Reading status: unread / reading / completed (donut)
- Hover any chart element to highlight it and see a tooltip with exact numbers
- Charts animate in (donuts sweep open, bars grow) whenever a page is shown
- Monthly purchases pairs book counts (columns) with a rupee spend line
- All prices are in Indian rupees (₹) with lakh/crore digit grouping

## Motion & polish

- Sidebar: a pill glides between menu tabs, tabs ease a highlight on hover, and
  the « / » button collapses the sidebar to an icon rail with a smooth width
  animation. Pages fade in on switch.
- Cards (stat cards and content cards) subtly brighten and tint their border
  on hover.

## Setup

```bash
cd amazon_book_manager
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

Requires **Python 3.9+**. A local `library.db` SQLite file is created
automatically next to `database.py` on first run — no setup required.

## Project Structure

```
amazon_book_manager/
├── main.py                 # App entry point
├── database.py              # SQLite data layer (books, lending, analytics queries)
├── currency.py               # ₹ formatting (Indian digit grouping)
├── styles.py                 # Dark, minimal QSS theme
├── requirements.txt
└── ui/
    ├── main_window.py        # Sidebar navigation + page switching
    ├── dashboard.py           # KPI cards + genre chart
    ├── book_collection.py     # Book table, search/filter, CRUD
    ├── lending_register.py    # Lending table, search/filter, CRUD
    ├── analytics.py           # Summary strip + chart grid (scrollable)
    ├── charts.py              # Chart drawing: donut + legend, ranked bars, monthly columns
    ├── dialogs.py              # Add/Edit dialogs for books & lending
    └── widgets.py               # Reusable StatCard / Card components
```

## Notes

- A book can only be deleted if it isn't currently lent out.
- "Overdue" status is computed automatically whenever data is loaded: any
  active loan past its expected return date (with no actual return date) is
  flagged.
- All data stays local in `library.db` — nothing leaves your machine.

## Customizing the look

Colors and spacing live in `styles.py` as a single QSS string — tweak the
hex values there (accent purple `#7C6CF0`, background `#14141C`, etc.) to
retheme the whole app in one place.
