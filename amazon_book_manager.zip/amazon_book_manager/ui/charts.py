"""Chart drawing helpers for Bookshelf.

Everything here works on a plain matplotlib ``Figure`` (no Qt imports), so the
same functions render inside the app and can be tested headlessly.

Design rules used for readability:
  * No text is placed on top of pie wedges - donuts get a side legend that
    lists name, count and percentage, plus the total in the centre.
  * Bar charts show the value at the end of each bar; no clutter axes.
  * Long titles are shortened with an ellipsis instead of being cut mid-word.
  * Missing months are filled in so trends never mislead.
  * A consistent colour per meaning (e.g. Unread / Reading / Completed).
  * Every draw function takes ``progress`` (0..1) so the canvas can animate
    the chart growing in; ``progress=1`` is the final, static picture.
"""

from datetime import date

from currency import compact_inr

import matplotlib
import matplotlib.lines
import matplotlib.patches
import matplotlib.ticker
from matplotlib import font_manager
from matplotlib.patches import Wedge

# ---- Theme -------------------------------------------------------------- #
BG = "#1D1D28"          # card background (charts sit inside cards)
TEXT = "#E5E5F0"
MUTED = "#8A8AA0"
GRID = "#2C2C3A"

PALETTE = [
    "#7C6CF0", "#2DD4A7", "#FBBF24", "#FF7A7A",
    "#5AB4FF", "#C084FC", "#F472B6", "#94A3B8",
]

STATUS_COLORS = {
    "Unread": "#8A8AA0",
    "Reading": "#FBBF24",
    "Completed": "#2DD4A7",
}


def _pick_font():
    installed = {f.name for f in font_manager.fontManager.ttflist}
    for name in ("Segoe UI", "Inter", "Helvetica Neue", "Arial", "DejaVu Sans"):
        if name in installed:
            return name
    return "sans-serif"


matplotlib.rcParams["font.family"] = _pick_font()
matplotlib.rcParams["axes.unicode_minus"] = False


# ---- Small helpers ------------------------------------------------------ #
def shorten(text: str, limit: int = 26) -> str:
    text = str(text)
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _empty(fig, message):
    fig.clear()
    ax = fig.add_subplot(111)
    ax.set_facecolor("none")
    ax.text(0.5, 0.5, message, ha="center", va="center", fontsize=10.5,
            color=MUTED, transform=ax.transAxes)
    ax.axis("off")


def _clean_axes(ax):
    ax.set_facecolor("none")
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=9, length=0)


def _blend(hex_a, hex_b, t):
    """Mix two #RRGGBB colours (t=0 -> a, t=1 -> b)."""
    a = [int(hex_a[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hex_b[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02X}" for x, y in zip(a, b))


def _group_small(data, max_items):
    """Keep the biggest ``max_items - 1`` slices and merge the rest into 'Other'."""
    if len(data) <= max_items:
        return data
    head = data[: max_items - 1]
    rest = sum(v for _, v in data[max_items - 1:])
    return head + [("Other", rest)]


# ---- Donut with legend -------------------------------------------------- #
def draw_donut(fig, data, empty_message="No data yet", colors=None,
               center_label="books", max_items=7, progress=1.0):
    """Donut chart + readable legend (name, count, percent).

    ``data`` is a list of ``(label, value)`` pairs. ``colors`` may be a dict
    label -> colour or a list; defaults to the shared palette. ``progress``
    sweeps the ring open from 0 to 360 degrees for the entrance animation.
    """
    data = [(k, v) for k, v in data if v > 0]
    if not data:
        _empty(fig, empty_message)
        return []

    data = _group_small(data, max_items)
    total = sum(v for _, v in data)

    def colour_for(i, label):
        if isinstance(colors, dict) and label in colors:
            return colors[label]
        pal = colors if isinstance(colors, (list, tuple)) else PALETTE
        return pal[i % len(pal)]

    fig.clear()
    gs = fig.add_gridspec(1, 2, width_ratios=[1, 1.15], wspace=0.05,
                          left=0.03, right=0.98, top=0.96, bottom=0.04)

    # -- donut
    ax = fig.add_subplot(gs[0, 0])
    ax.set_aspect("equal")
    ax.set_xlim(-1.1, 1.1)
    ax.set_ylim(-1.1, 1.1)
    ax.axis("off")

    # faint background ring so the sweep animation has a track to fill
    ax.add_patch(Wedge((0, 0), 1.0, 0, 360, width=0.34, facecolor="#242433",
                       edgecolor="none", zorder=0))

    wedges = []
    angle = 90.0
    gap = 1.2 if len(data) > 1 else 0
    for i, (label, value) in enumerate(data):
        full = 360.0 * value / total
        sweep = full * progress
        w = Wedge((0, 0), 1.0, angle - sweep + gap / 2, angle - gap / 2,
                  width=0.34, facecolor=colour_for(i, label), edgecolor="none",
                  zorder=2)
        ax.add_patch(w)
        wedges.append((w, label, value))
        angle -= full * progress

    ax.text(0, 0.08, f"{round(total * progress) if progress < 1 else total}",
            ha="center", va="center", fontsize=24, fontweight="bold", color="#FFFFFF")
    ax.text(0, -0.24, center_label, ha="center", va="center", fontsize=9.5, color=MUTED)

    # -- legend (drawn as text so we control alignment)
    lax = fig.add_subplot(gs[0, 1])
    lax.axis("off")
    lax.set_xlim(0, 1)
    lax.set_ylim(0, 1)

    n = len(data)
    row_h = min(0.14, 0.92 / n)
    y0 = 0.5 + (n - 1) * row_h / 2
    fade = min(1.0, progress * 1.6)
    for i, (label, value) in enumerate(data):
        y = y0 - i * row_h
        pct = value / total * 100
        lax.scatter([0.03], [y], s=70, color=colour_for(i, label), marker="s",
                    transform=lax.transAxes, clip_on=False, alpha=fade)
        lax.text(0.10, y, shorten(label, 20), va="center", ha="left",
                 fontsize=10, color=TEXT, transform=lax.transAxes, alpha=fade)
        lax.text(0.99, y, f"{value}  \u00b7  {pct:.0f}%", va="center", ha="right",
                 fontsize=10, color=MUTED, transform=lax.transAxes, alpha=fade)
    return wedges


# ---- Horizontal bars ---------------------------------------------------- #
def draw_hbar(fig, data, color="#7C6CF0", empty_message="No data yet",
              max_items=8, label_limit=22, progress=1.0):
    """Ranked horizontal bars: rank-faded colour, value printed at the bar end,
    growing in from the left when ``progress`` runs 0 -> 1."""
    data = [(k, v) for k, v in data if v > 0][:max_items]
    if not data:
        _empty(fig, empty_message)
        return []

    fig.clear()
    ax = fig.add_subplot(111)
    _clean_axes(ax)
    ax.spines["bottom"].set_visible(False)

    labels = [shorten(k, label_limit) for k, _ in data]
    values = [v for _, v in data]
    ypos = list(range(len(data)))
    top = max(values)

    # faint full-width track behind each bar makes rows easy to follow
    ax.barh(ypos, [top] * len(values), color="#242433", height=0.62, zorder=1)
    # the leader gets the full colour, lower ranks fade slightly towards the track
    n = len(data)
    colours = [_blend(color, "#3A3A52", 0.45 * i / max(n - 1, 1)) for i in range(n)]
    bars = ax.barh(ypos, [v * progress for v in values], color=colours,
                   height=0.62, zorder=2)

    ax.set_yticks(ypos)
    ax.set_yticklabels(labels, fontsize=9.5, color=TEXT)
    ax.invert_yaxis()
    ax.set_xlim(0, top * 1.12)
    ax.set_xticks([])
    ax.tick_params(axis="y", pad=8)

    for bar, v in zip(bars, values):
        ax.text(bar.get_width() + top * 0.015, bar.get_y() + bar.get_height() / 2,
                f"{v}", va="center", ha="left", fontsize=9.5,
                fontweight="bold", color=TEXT, zorder=3,
                alpha=min(1.0, progress * 1.5))
    fig.subplots_adjust(left=0.40, right=0.97, top=0.97, bottom=0.04)
    return list(zip(bars, [k for k, _ in data], values))


# ---- Monthly trend ------------------------------------------------------ #
def _fill_months(data):
    """data: [(YYYY-MM, count, total)] -> continuous months with zeros filled."""
    if not data:
        return []
    lookup = {ym: (c, t) for ym, c, t in data}
    y, m = map(int, data[0][0].split("-"))
    ey, em = map(int, data[-1][0].split("-"))
    out = []
    while (y, m) <= (ey, em):
        key = f"{y:04d}-{m:02d}"
        c, t = lookup.get(key, (0, 0))
        out.append((key, c, t))
        m += 1
        if m > 12:
            m, y = 1, y + 1
    return out


def _month_label(ym, with_year):
    y, m = map(int, ym.split("-"))
    name = date(y, m, 1).strftime("%b")
    return f"{name}\n{str(y)[2:]}" if with_year else name


def draw_monthly(fig, data, empty_message="No purchase dates recorded yet", progress=1.0):
    """Columns = books bought per month (left axis, counts on top) with a
    smooth line for rupees spent (right axis) when prices are recorded."""
    rows = _fill_months(data)
    if not rows:
        _empty(fig, empty_message)
        return []

    fig.clear()
    ax = fig.add_subplot(111)
    _clean_axes(ax)

    counts = [c for _, c, _ in rows]
    spends = [t for _, _, t in rows]
    x = list(range(len(rows)))
    top = max(counts) or 1

    ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
    ax.set_axisbelow(True)
    bars = ax.bar(x, [c * progress for c in counts], color="#FBBF24", width=0.52, zorder=2)
    for xi, c in zip(x, counts):
        if c:
            ax.text(xi, c * progress + top * 0.03, str(c), ha="center", va="bottom",
                    fontsize=9.5, fontweight="bold", color=TEXT,
                    alpha=min(1.0, progress * 1.5), zorder=4)

    # a single label is enough per tick: show the year only when it changes
    labels = []
    prev_year = None
    for ym, _, _ in rows:
        year = ym[:4]
        labels.append(_month_label(ym, year != prev_year))
        prev_year = year
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9, color=MUTED)
    ax.set_xlim(-0.6, len(rows) - 0.4)
    ax.set_ylim(0, top * 1.3)
    ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True, nbins=4))

    handles = [matplotlib.patches.Patch(color="#FBBF24", label="Books bought")]
    if any(spends):
        ax2 = ax.twinx()
        ax2.set_facecolor("none")
        for spine in ax2.spines.values():
            spine.set_visible(False)
        ax2.tick_params(colors=MUTED, labelsize=9, length=0)
        ax2.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: compact_inr(v)))
        ax2.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(nbins=4))
        ax2.set_ylim(0, max(spends) * 1.3)
        ax2.plot(x, [s * progress for s in spends], color="#7C6CF0", linewidth=2.2,
                 marker="o", markersize=5.5, markerfacecolor="#7C6CF0",
                 markeredgecolor=BG, markeredgewidth=1.5, zorder=5)
        handles.append(matplotlib.lines.Line2D([0], [0], color="#7C6CF0", linewidth=2.2,
                                               marker="o", markersize=5.5,
                                               label="Spent (\u20b9)"))
        right = 0.88
    else:
        right = 0.98

    leg = ax.legend(handles=handles, loc="upper left", ncol=len(handles), frameon=False,
                    fontsize=9, handlelength=1.4, columnspacing=1.6, borderaxespad=0.2)
    for t in leg.get_texts():
        t.set_color(MUTED)
    fig.subplots_adjust(left=0.08, right=right, top=0.95, bottom=0.2)

    return [(b, rows[i][0], rows[i][1], rows[i][2]) for i, b in enumerate(bars)]
