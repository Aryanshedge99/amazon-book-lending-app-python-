"""Reusable UI building blocks: page header, hover-animated stat/content cards
and a matplotlib chart canvas with entrance animation, hover highlight and
tooltips."""

from PySide6.QtCore import QEasingCurve, QRectF, Qt, QVariantAnimation
from PySide6.QtGui import QColor, QCursor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QSizePolicy, QToolTip, QVBoxLayout, QWidget
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.patches import Wedge

CARD_BG = "#1D1D28"
CARD_BG_HOVER = "#222232"
CARD_BORDER = "#2A2A3A"


def _mix(c1: QColor, c2: QColor, t: float) -> QColor:
    """Linear blend between two colours (t=0 -> c1, t=1 -> c2)."""
    return QColor(
        round(c1.red() + (c2.red() - c1.red()) * t),
        round(c1.green() + (c2.green() - c1.green()) * t),
        round(c1.blue() + (c2.blue() - c1.blue()) * t),
    )


class PageHeader(QWidget):
    """Big page title with a muted one-line description underneath."""

    def __init__(self, title: str, subtitle: str = ""):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        t = QLabel(title)
        t.setObjectName("pageTitle")
        layout.addWidget(t)
        if subtitle:
            s = QLabel(subtitle)
            s.setObjectName("pageSubtitle")
            layout.addWidget(s)


class HoverFrame(QFrame):
    """Rounded card that eases its background and border towards an accent
    tint when the mouse is over it. Fully custom-painted because Qt style
    sheets can't animate."""

    RADIUS = 16

    def __init__(self, accent: str = "#7C6CF0"):
        super().__init__()
        self._t = 0.0
        self._accent = QColor(accent)
        self._bg = QColor(CARD_BG)
        self._bg_hover = QColor(CARD_BG_HOVER)
        self._border = QColor(CARD_BORDER)
        self._border_hover = _mix(self._border, self._accent, 0.55)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)

    def _on_anim(self, value):
        self._t = float(value)
        self.update()

    def _animate_to(self, target: float):
        self._anim.stop()
        self._anim.setStartValue(self._t)
        self._anim.setEndValue(target)
        self._anim.start()

    def enterEvent(self, event):
        self._animate_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._animate_to(0.0)
        super().leaveEvent(event)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        path = QPainterPath()
        path.addRoundedRect(rect, self.RADIUS, self.RADIUS)
        p.fillPath(path, _mix(self._bg, self._bg_hover, self._t))
        p.setPen(QPen(_mix(self._border, self._border_hover, self._t), 1))
        p.drawPath(path)


class StatCard(HoverFrame):
    """Dashboard KPI card: coloured icon chip, big value, caption and hint."""

    def __init__(self, icon: str, title: str, value="0", accent="#7C6CF0", hint: str = ""):
        super().__init__(accent)
        self.setObjectName("statCard")
        self.setMinimumHeight(112)

        root = QHBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(14)

        chip = QLabel(icon)
        chip.setAlignment(Qt.AlignCenter)
        chip.setFixedSize(46, 46)
        chip.setStyleSheet(
            f"background-color: {accent}26; border-radius: 12px; font-size: 20px;"
        )
        root.addWidget(chip, 0, Qt.AlignTop)

        text = QVBoxLayout()
        text.setSpacing(1)
        self.title_lbl = QLabel(title)
        self.title_lbl.setObjectName("statTitle")
        self.value_lbl = QLabel(str(value))
        self.value_lbl.setObjectName("statValue")
        self.hint_lbl = QLabel(hint)
        self.hint_lbl.setObjectName("statHint")
        self.hint_lbl.setVisible(bool(hint))
        text.addWidget(self.title_lbl)
        text.addWidget(self.value_lbl)
        text.addWidget(self.hint_lbl)
        text.addStretch()
        root.addLayout(text, 1)

    def set_value(self, value, hint: str = None):
        self.value_lbl.setText(str(value))
        if hint is not None:
            self.hint_lbl.setText(hint)
            self.hint_lbl.setVisible(bool(hint))


class Card(HoverFrame):
    """Rounded container with optional title + subtitle, used to frame
    tables and charts consistently across pages."""

    def __init__(self, title: str = None, subtitle: str = None):
        super().__init__()
        self.setObjectName("card")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(20, 16, 20, 16)
        self.layout.setSpacing(10)
        if title:
            lbl = QLabel(title)
            lbl.setObjectName("cardTitle")
            self.layout.addWidget(lbl)
        if subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("cardSubtitle")
            sub.setWordWrap(True)
            self.layout.addWidget(sub)


class ChartCanvas(FigureCanvas):
    """A matplotlib canvas that blends into the cards, highlights the
    hovered element and shows a tooltip.

    Usage: ``canvas.play(draw_fn)`` where ``draw_fn(fig, progress)`` draws the
    chart (``progress`` is always 1.0 - the parameter is kept so existing
    ``charts.py`` draw functions don't need to change) and returns a list of
    ``(artist, tooltip)`` (or longer tuples - only the first element is used
    as the artist).

    Note: this used to animate every chart growing in on each refresh (a
    ~700ms loop that fully rebuilt the Matplotlib figure on every frame).
    That made the whole app feel laggy, especially since editing a single
    book could trigger up to six of these animations at once (Dashboard +
    Analytics charts). Charts now draw once, instantly, and stay just as
    interactive on hover.
    """

    def __init__(self, min_height: int = 240):
        fig = Figure(figsize=(5, 3), dpi=100, facecolor="none")
        super().__init__(fig)
        self.setStyleSheet("background: transparent;")
        self.setMinimumHeight(min_height)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._hover_items = []
        self._hover_idx = -1
        self._base = {}
        self.mpl_connect("motion_notify_event", self._on_move)
        self.mpl_connect("figure_leave_event", self._on_leave)

    # ---- drawing ------------------------------------------------------- #
    def play(self, draw_fn):
        """Draw the chart once and wire up hover interactivity."""
        self._reset_hover()
        self.set_hover_items(draw_fn(self.figure, 1.0))
        self.draw_idle()

    def set_hover_items(self, items):
        self._reset_hover()
        self._hover_items = items or []
        self._base = {}
        for it in self._hover_items:
            art = it[0]
            if isinstance(art, Wedge):
                self._base[id(art)] = (art.r, art.width)

    # ---- hover --------------------------------------------------------- #
    def _reset_hover(self):
        self._hover_idx = -1

    def _apply_highlight(self, idx):
        for i, it in enumerate(self._hover_items):
            art = it[0]
            active = idx == i
            dim = idx != -1 and not active
            art.set_alpha(0.45 if dim else 1.0)
            if isinstance(art, Wedge) and id(art) in self._base:
                r, w = self._base[id(art)]
                grow = 0.06 if active else 0.0
                art.set_radius(r + grow)
                art.set_width(w + grow)
        self.draw_idle()

    def _on_move(self, event):
        hit_idx, text = -1, None
        if event.inaxes is not None or event.x is not None:
            for i, it in enumerate(self._hover_items):
                try:
                    hit, _ = it[0].contains(event)
                except Exception:
                    hit = False
                if hit:
                    hit_idx, text = i, it[1]
                    break
        if hit_idx != self._hover_idx:
            self._hover_idx = hit_idx
            self._apply_highlight(hit_idx)
        if hit_idx >= 0:
            self.setCursor(QCursor(Qt.PointingHandCursor))
            QToolTip.showText(QCursor.pos(), text, self)
        else:
            self.unsetCursor()
            QToolTip.hideText()

    def _on_leave(self, _event):
        if self._hover_idx != -1:
            self._hover_idx = -1
            self._apply_highlight(-1)
        self.unsetCursor()
        QToolTip.hideText()
