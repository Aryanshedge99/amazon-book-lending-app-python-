"""Main application window: animated sidebar navigation + stacked pages.

Sidebar motion:
  * the sidebar rests as a narrow icon rail and glides open the moment the
    mouse enters it, closing again the moment the mouse leaves - no click
    needed. Click the pin to keep it open permanently.
  * an accent "pill" glides between menu tabs when you switch pages
  * each tab eases in a soft highlight and nudges its label on hover
  * pages fade in when you switch to them
"""

from PySide6.QtCore import (
    QEasingCurve,
    QEvent,
    QPropertyAnimation,
    QRect,
    QRectF,
    Qt,
    QTimer,
    QVariantAnimation,
)
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath
from PySide6.QtWidgets import (
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QPushButton,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .analytics import AnalyticsPage
from .book_collection import BookCollectionPage
from .dashboard import DashboardPage
from .lending_register import LendingRegisterPage

NAV_ITEMS = [
    ("📊", "Dashboard"),
    ("📚", "Collection"),
    ("🤝", "Lending"),
    ("📈", "Analytics"),
]

SIDEBAR_OPEN = 232
SIDEBAR_CLOSED = 68
ICON_CENTER_X = 22      # icon stays put while the sidebar resizes
LABEL_X = 48


def _clamp01(v: float) -> float:
    return max(0.0, min(1.0, v))


class NavButton(QPushButton):
    """Menu tab drawn by hand so hover can be animated: a soft highlight fades
    in and the label slides a few pixels right. The active tab's background is
    the sliding pill behind it, so this button never paints a checked fill."""

    def __init__(self, icon: str, label: str):
        super().__init__()
        self.icon_text = icon
        self.label_text = label
        self._t = 0.0
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self.setFixedHeight(44)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(170)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)

    def _on_anim(self, v):
        self._t = float(v)
        self.update()

    def _animate_to(self, target):
        self._anim.stop()
        self._anim.setStartValue(self._t)
        self._anim.setEndValue(target)
        self._anim.start()

    def enterEvent(self, event):
        self._animate_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._animate_to(0.0)
        super().leaveEvent(event)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        h = self.height()
        checked = self.isChecked()

        # soft hover highlight (the active tab already has the pill)
        if not checked and self._t > 0:
            path = QPainterPath()
            path.addRoundedRect(QRectF(self.rect()), 10, 10)
            p.fillPath(path, QColor(255, 255, 255, round(16 * self._t)))

        # icon: stays at a fixed x, lifts a hair on hover
        icon_font = QFont(self.font())
        icon_font.setPixelSize(18)
        p.setFont(icon_font)
        p.setPen(QColor("#FFFFFF") if checked else QColor(255, 255, 255, round(190 + 65 * self._t)))
        p.drawText(QRect(ICON_CENTER_X - 16, 0, 32, h), Qt.AlignCenter, self.icon_text)

        # label: fades with the sidebar width, nudges right on hover
        fade = _clamp01((self.width() - 90) / 90.0)
        if fade > 0:
            f = QFont(self.font())
            f.setPixelSize(14)
            f.setWeight(QFont.DemiBold if checked else QFont.Normal)
            p.setFont(f)
            if checked:
                col = QColor("#FFFFFF")
            else:
                a, b = QColor("#A2A2BA"), QColor("#FFFFFF")
                col = QColor(
                    round(a.red() + (b.red() - a.red()) * self._t),
                    round(a.green() + (b.green() - a.green()) * self._t),
                    round(a.blue() + (b.blue() - a.blue()) * self._t),
                )
            col.setAlphaF(fade)
            p.setPen(col)
            x = LABEL_X + round(3 * self._t)
            p.drawText(QRect(x, 0, max(0, self.width() - x - 6), h),
                       Qt.AlignVCenter | Qt.AlignLeft, self.label_text)


class MainWindow(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.db = db
        self.setWindowTitle("Bookshelf — Collection & Lending Manager")
        self.resize(1280, 820)
        self.setMinimumSize(980, 620)

        self._collapsed = True      # visual state: currently shown narrow?
        self._pinned = False        # user locked it open via the pin button
        self._hovering = False      # mouse is currently over the sidebar
        self._current_idx = 0
        self._fade_anim = None
        self._fade_page = None

        central = QWidget()
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())
        # Starts collapsed: pre-fill tooltips so labels are still discoverable
        # before the very first hover.
        for btn in self.nav_buttons:
            btn.setToolTip(btn.label_text)
        self.pin_btn.setToolTip("Pin sidebar open")

        self.stack = QStackedWidget()
        self.dashboard_page = DashboardPage(self.db)
        self.collection_page = BookCollectionPage(self.db, on_change=self.refresh_summaries)
        self.lending_page = LendingRegisterPage(self.db, on_change=self.refresh_summaries)
        self.analytics_page = AnalyticsPage(self.db)
        self.pages = [self.dashboard_page, self.collection_page,
                      self.lending_page, self.analytics_page]

        for page in self.pages:
            self.stack.addWidget(page)

        root.addWidget(self.stack, 1)
        self.setCentralWidget(central)

        self.nav_buttons[0].setChecked(True)
        QTimer.singleShot(0, self._snap_pill)

    # ------------------------------------------------------------------ #
    # Sidebar
    # ------------------------------------------------------------------ #
    def _build_sidebar(self):
        self.sidebar = QWidget()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(SIDEBAR_CLOSED)
        self.sidebar.installEventFilter(self)

        side = QVBoxLayout(self.sidebar)
        side.setContentsMargins(12, 24, 12, 16)
        side.setSpacing(6)

        # brand row: icon stays, text fades
        brand_row = QHBoxLayout()
        brand_row.setContentsMargins(0, 0, 0, 0)
        brand_row.setSpacing(0)
        brand_icon = QLabel("📘")
        brand_icon.setObjectName("brandIcon")
        brand_icon.setAlignment(Qt.AlignCenter)
        brand_icon.setFixedSize(2 * ICON_CENTER_X, 40)
        brand_row.addWidget(brand_icon)

        brand_text = QWidget()
        brand_text.setObjectName("sidebarInner")
        brand_text.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        bt = QVBoxLayout(brand_text)
        bt.setContentsMargins(4, 0, 0, 0)
        bt.setSpacing(0)
        brand = QLabel("Bookshelf")
        brand.setObjectName("brand")
        brand_sub = QLabel("Collection & lending")
        brand_sub.setObjectName("brandSub")
        bt.addWidget(brand)
        bt.addWidget(brand_sub)
        brand_row.addWidget(brand_text, 1)
        side.addLayout(brand_row)
        side.addSpacing(18)

        section = QLabel("MENU")
        section.setObjectName("sidebarSection")
        section.setContentsMargins(6, 0, 0, 0)
        section.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        side.addWidget(section)
        side.addSpacing(2)

        # nav container hosts the buttons and the sliding pill
        self.nav_container = QWidget()
        self.nav_container.setObjectName("navContainer")
        nav_layout = QVBoxLayout(self.nav_container)
        nav_layout.setContentsMargins(0, 0, 0, 0)
        nav_layout.setSpacing(4)

        self.nav_buttons = []
        for i, (icon, name) in enumerate(NAV_ITEMS):
            btn = NavButton(icon, name)
            btn.clicked.connect(lambda _c=False, n=name: self.switch_page(n))
            nav_layout.addWidget(btn)
            self.nav_buttons.append(btn)

        self.pill = QFrame(self.nav_container)
        self.pill.setObjectName("navPill")
        self.pill.lower()  # behind the buttons
        self._pill_anim = QPropertyAnimation(self.pill, b"geometry", self)
        self._pill_anim.setDuration(320)
        self._pill_anim.setEasingCurve(QEasingCurve.OutCubic)
        self.nav_container.installEventFilter(self)
        side.addWidget(self.nav_container)

        side.addStretch()

        # pin: keeps the sidebar open even when the mouse isn't over it
        self.pin_btn = NavButton("📌", "Pin open")
        self.pin_btn.setCheckable(True)
        self.pin_btn.toggled.connect(self._on_pin_toggled)
        side.addWidget(self.pin_btn)

        self.footer = QLabel("SQLite · Local & Private")
        self.footer.setObjectName("sidebarFooter")
        self.footer.setContentsMargins(6, 4, 0, 0)
        self.footer.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        side.addWidget(self.footer)

        # widgets whose opacity follows the sidebar width
        self._fading = []
        for w in (brand_text, section, self.footer):
            eff = QGraphicsOpacityEffect(w)
            w.setGraphicsEffect(eff)
            self._fading.append(eff)

        self._width_anim = QVariantAnimation(self)
        self._width_anim.setDuration(280)
        self._width_anim.setEasingCurve(QEasingCurve.InOutCubic)
        self._width_anim.valueChanged.connect(self._on_width)

        return self.sidebar

    def _on_width(self, value):
        w = int(value)
        self.sidebar.setFixedWidth(w)
        opacity = _clamp01((w - 120) / 90.0)
        for eff in self._fading:
            eff.setOpacity(opacity)

    def _set_sidebar_expanded(self, expand: bool):
        """Animate the sidebar open or closed. Safe to call mid-animation -
        it just redirects smoothly from wherever the width currently is,
        so rapid hover in/out never stutters or jumps."""
        self._collapsed = not expand
        target = SIDEBAR_OPEN if expand else SIDEBAR_CLOSED
        if self._width_anim.endValue() == target and self._width_anim.state() == QVariantAnimation.Running:
            return  # already animating the same way - let it finish smoothly
        self._width_anim.stop()
        self._width_anim.setStartValue(self.sidebar.width())
        self._width_anim.setEndValue(target)
        self._width_anim.start()

        # Tooltips only matter while the sidebar is visually narrow, so the
        # label is still discoverable even mid-hover-in before it's readable.
        self.pin_btn.setToolTip("" if expand else "Pin sidebar open")
        for btn in self.nav_buttons:
            btn.setToolTip(btn.label_text if self._collapsed else "")

    def _on_pin_toggled(self, checked: bool):
        self._pinned = checked
        # Pinning always opens; unpinning falls back to whatever the mouse
        # is doing right now (stay open if it's still hovering, else close).
        self._set_sidebar_expanded(checked or self._hovering)

    # ---- hover open/close ------------------------------------------------ #
    def _on_sidebar_enter(self):
        self._hovering = True
        if not self._pinned:
            self._set_sidebar_expanded(True)

    def _on_sidebar_leave(self):
        self._hovering = False
        if not self._pinned:
            self._set_sidebar_expanded(False)

    # ---- sliding pill --------------------------------------------------- #
    def eventFilter(self, obj, event):
        if obj is self.sidebar:
            if event.type() == QEvent.Enter:
                self._on_sidebar_enter()
            elif event.type() == QEvent.Leave:
                self._on_sidebar_leave()
        elif obj is self.nav_container and event.type() in (QEvent.Resize, QEvent.LayoutRequest):
            if self._pill_anim.state() != QPropertyAnimation.Running:
                self._snap_pill()
        return super().eventFilter(obj, event)

    def _snap_pill(self):
        btn = self.nav_buttons[self._current_idx]
        self.pill.setGeometry(btn.geometry())
        self.pill.lower()

    def _slide_pill_to(self, idx):
        target = self.nav_buttons[idx].geometry()
        self._pill_anim.stop()
        self._pill_anim.setStartValue(self.pill.geometry())
        self._pill_anim.setEndValue(target)
        self._pill_anim.start()

    # ------------------------------------------------------------------ #
    # Navigation
    # ------------------------------------------------------------------ #
    def switch_page(self, name: str):
        idx = [n for _, n in NAV_ITEMS].index(name)
        page = self.pages[idx]
        changed = idx != self._current_idx

        for i, btn in enumerate(self.nav_buttons):
            btn.setChecked(i == idx)
        if changed:
            self._slide_pill_to(idx)
        self._current_idx = idx
        self.stack.setCurrentIndex(idx)

        if hasattr(page, "refresh"):
            page.refresh()
        if changed:
            self._fade_in(page)

    def _fade_in(self, page):
        # drop any half-finished fade first
        if self._fade_anim is not None:
            self._fade_anim.stop()
        if self._fade_page is not None:
            self._fade_page.setGraphicsEffect(None)

        effect = QGraphicsOpacityEffect(page)
        effect.setOpacity(0.0)
        page.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity")
        # Shorter than before (was 240ms): fading a whole page's opacity forces
        # Qt to re-composite it every frame, which felt sluggish stacked on
        # top of the page's own refresh(). A quick 140ms fade keeps the polish
        # without the drag.
        anim.setDuration(140)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.finished.connect(lambda p=page: p.setGraphicsEffect(None))
        self._fade_anim, self._fade_page = anim, page
        anim.start()

    def refresh_summaries(self):
        """Called by the Collection/Lending pages whenever data changes, so the
        Dashboard and Analytics stay in sync without a manual refresh."""
        self.dashboard_page.refresh()
        self.analytics_page.refresh()
