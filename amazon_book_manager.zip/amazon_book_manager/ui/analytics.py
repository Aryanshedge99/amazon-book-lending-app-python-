"""Analytics page: summary strip + genre split, most-lent books,
monthly purchases and reading statistics."""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QGridLayout, QHBoxLayout, QScrollArea, QVBoxLayout, QWidget

from currency import format_inr

from . import charts
from .widgets import Card, ChartCanvas, PageHeader, StatCard


class AnalyticsPage(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        # Scroll area so charts keep a comfortable size on small windows
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        outer.addWidget(scroll)

        body = QWidget()
        scroll.setWidget(body)
        layout = QVBoxLayout(body)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(20)

        layout.addWidget(PageHeader("Analytics", "Trends and insights about your collection. Hover over a chart for details."))

        # ---- Summary strip
        strip = QHBoxLayout()
        strip.setSpacing(16)
        self.spent_card = StatCard("💰", "Total Spent", accent="#FBBF24")
        self.avg_card = StatCard("🏷️", "Average Price", accent="#5AB4FF")
        self.done_card = StatCard("✅", "Books Completed", accent="#2DD4A7")
        self.top_card = StatCard("🔥", "Most Lent Book", accent="#FF7A7A")
        for c in (self.spent_card, self.avg_card, self.done_card, self.top_card):
            strip.addWidget(c, 1)
        layout.addLayout(strip)

        # ---- Charts
        grid = QGridLayout()
        grid.setSpacing(16)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)

        self.genre_card, self.genre_canvas = self._chart_card(
            "Books by Genre", "Share of your collection per genre")
        self.reading_card, self.reading_canvas = self._chart_card(
            "Reading Status", "Unread, currently reading and completed")
        self.lent_card, self.lent_canvas = self._chart_card(
            "Most Frequently Lent", "Books that travel the most")
        self.purchase_card, self.purchase_canvas = self._chart_card(
            "Monthly Purchases", "Books bought per month", min_height=260)

        grid.addWidget(self.genre_card, 0, 0)
        grid.addWidget(self.reading_card, 0, 1)
        grid.addWidget(self.lent_card, 1, 0)
        grid.addWidget(self.purchase_card, 1, 1)
        layout.addLayout(grid)
        layout.addStretch()

        self.refresh()

    def _chart_card(self, title, subtitle, min_height=260):
        card = Card(title, subtitle)
        canvas = ChartCanvas(min_height=min_height)
        card.layout.addWidget(canvas, 1)
        return card, canvas

    # ------------------------------------------------------------------ #
    def refresh(self):
        self._draw_summary()
        self._draw_genre()
        self._draw_reading()
        self._draw_lent()
        self._draw_purchases()

    @staticmethod
    def _plural(n, word="book"):
        return f"{n} {word}{'' if n == 1 else 's'}"

    def _draw_summary(self):
        spend = self.db.get_spending_summary()
        self.spent_card.set_value(format_inr(spend["total"], 0),
                                  f"across {self._plural(spend['priced_books'])}")
        self.avg_card.set_value(format_inr(spend["average"]), "per book")

        reading = self.db.get_reading_stats()
        total = sum(reading.values())
        done = reading.get("Completed", 0)
        self.done_card.set_value(done, f"{done * 100 // total}% of your books" if total else "")

        top = self.db.get_most_lent_books(1)
        if top:
            self.top_card.set_value(charts.shorten(top[0][0], 16), f"lent {top[0][1]}×")
        else:
            self.top_card.set_value("—", "no lending yet")

    def _draw_genre(self):
        data = self.db.get_books_by_genre()
        self.genre_canvas.play(lambda fig, p: [
            (w, f"{label}: {self._plural(v)}")
            for w, label, v in charts.draw_donut(
                fig, data, empty_message="Add books to see your genre split", progress=p)
        ])

    def _draw_reading(self):
        reading = self.db.get_reading_stats()
        order = ["Completed", "Reading", "Unread"]
        data = [(k, reading[k]) for k in order if k in reading]
        data += [(k, v) for k, v in reading.items() if k not in order]
        self.reading_canvas.play(lambda fig, p: [
            (w, f"{label}: {self._plural(v)}")
            for w, label, v in charts.draw_donut(
                fig, data, colors=charts.STATUS_COLORS,
                empty_message="Add books to track your reading", progress=p)
        ])

    def _draw_lent(self):
        data = self.db.get_most_lent_books(8)
        self.lent_canvas.play(lambda fig, p: [
            (b, f"{name}\nLent {v}\u00d7")
            for b, name, v in charts.draw_hbar(
                fig, data, color="#2DD4A7", empty_message="No lending history yet", progress=p)
        ])

    @staticmethod
    def _month_name(ym):
        y, m = ym.split("-")
        names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        return f"{names[int(m) - 1]} {y}"

    def _draw_purchases(self):
        data = self.db.get_monthly_purchases(12)

        def draw(fig, p):
            items = []
            for bar, ym, count, total in charts.draw_monthly(
                    fig, data, empty_message="No purchase dates recorded yet", progress=p):
                tip = f"{self._month_name(ym)}: {self._plural(count)}"
                if total:
                    tip += f"\nSpent {format_inr(total)}"
                items.append((bar, tip))
            return items

        self.purchase_canvas.play(draw)
