"""Personal Lending Register page: track who has which of your books."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .dialogs import AddEditLendingDialog
from .widgets import Card, PageHeader

COLUMNS = ["Borrower", "Contact No.", "Book", "Date Lent", "Expected Return",
           "Actual Return", "Status", "Notes"]

STATUS_COLORS = {
    "Lent": QColor("#5AB4FF"),
    "Overdue": QColor("#FF7A7A"),
    "Returned": QColor("#2DD4A7"),
}


class LendingRegisterPage(QWidget):
    def __init__(self, db, on_change=None):
        super().__init__()
        self.db = db
        self.on_change = on_change
        self.rows_data = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        layout.addWidget(PageHeader("Lending Register", "Keep track of who has borrowed which book."))

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search by borrower or book title…")
        self.search_edit.textChanged.connect(self.refresh)

        self.status_filter = QComboBox()
        self.status_filter.addItems(["All", "Lent", "Overdue", "Returned"])
        self.status_filter.currentTextChanged.connect(self.refresh)

        add_btn = QPushButton("＋ Lend a Book")
        add_btn.setObjectName("primaryButton")
        add_btn.clicked.connect(self.add_record)

        toolbar.addWidget(self.search_edit, 2)
        toolbar.addWidget(self.status_filter, 1)
        toolbar.addStretch()
        toolbar.addWidget(add_btn)
        layout.addLayout(toolbar)

        card = Card()
        self.count_lbl = QLabel("")
        self.count_lbl.setObjectName("resultCount")
        card.layout.addWidget(self.count_lbl)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.horizontalHeader().setHighlightSections(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.doubleClicked.connect(self.edit_selected)
        card.layout.addWidget(self.table)
        layout.addWidget(card, 1)

        actions = QHBoxLayout()
        edit_btn = QPushButton("Edit")
        edit_btn.clicked.connect(self.edit_selected)
        return_btn = QPushButton("Mark Returned")
        return_btn.setObjectName("primaryButton")
        return_btn.clicked.connect(self.mark_returned)
        del_btn = QPushButton("Delete")
        del_btn.setObjectName("dangerButton")
        del_btn.clicked.connect(self.delete_selected)
        actions.addWidget(edit_btn)
        actions.addWidget(return_btn)
        actions.addWidget(del_btn)
        actions.addStretch()
        layout.addLayout(actions)

        self.refresh()

    def refresh(self):
        rows = self.db.get_lending_records(
            search=self.search_edit.text().strip(),
            status=self.status_filter.currentText(),
        )
        self.rows_data = rows
        self.count_lbl.setText(
            f"{len(rows)} record{'s' if len(rows) != 1 else ''}"
            + ("  ·  nothing here yet" if not rows else "  ·  double-click a row to edit")
        )
        self.table.setRowCount(len(rows))
        for r, rec in enumerate(rows):
            values = [
                rec["borrower_name"],
                rec.get("contact_number") or "—",
                rec["book_title"],
                rec["date_lent"],
                rec["expected_return_date"] or "—",
                rec["actual_return_date"] or "—",
                rec["lending_status"],
                rec["notes"] or "—",
            ]
            for c, val in enumerate(values):
                item = QTableWidgetItem(str(val))
                if c == 6:
                    item.setText("●  " + str(val))
                    item.setForeground(STATUS_COLORS.get(val, QColor("#E8E8F2")))
                elif c in (1, 3, 4, 5, 7):
                    item.setForeground(QColor("#A2A2BA"))
                self.table.setItem(r, c, item)
            self.table.item(r, 0).setData(Qt.UserRole, rec["id"])

    def selected_record(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows_data):
            return None
        return self.rows_data[row]

    def add_record(self):
        if not self.db.get_available_books():
            QMessageBox.information(
                self, "No Books Available",
                "All books are currently lent out, or your collection is empty.",
            )
            return
        dlg = AddEditLendingDialog(self, db=self.db)
        if dlg.exec():
            data = dlg.get_data()
            if not data["borrower_name"]:
                QMessageBox.warning(self, "Missing Name", "Borrower name is required.")
                return
            self.db.add_lending(data)
            self.refresh()
            if self.on_change:
                self.on_change()

    def edit_selected(self):
        rec = self.selected_record()
        if not rec:
            return
        dlg = AddEditLendingDialog(self, db=self.db, record=rec)
        if dlg.exec():
            data = dlg.get_data()
            if not data["borrower_name"]:
                QMessageBox.warning(self, "Missing Name", "Borrower name is required.")
                return
            self.db.update_lending(rec["id"], data)
            self.refresh()
            if self.on_change:
                self.on_change()

    def mark_returned(self):
        rec = self.selected_record()
        if not rec:
            return
        if rec["lending_status"] == "Returned":
            QMessageBox.information(self, "Already Returned", "This book has already been returned.")
            return
        self.db.mark_returned(rec["id"])
        self.refresh()
        if self.on_change:
            self.on_change()

    def delete_selected(self):
        rec = self.selected_record()
        if not rec:
            return
        confirm = QMessageBox.question(
            self, "Delete Record", f"Delete the lending record for '{rec['borrower_name']}'?"
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_lending(rec["id"])
            self.refresh()
            if self.on_change:
                self.on_change()
