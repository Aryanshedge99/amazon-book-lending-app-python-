"""Modal dialogs used to add / edit books and lending records."""

from PySide6.QtCore import QDate, QRegularExpression, Qt
from PySide6.QtGui import QRegularExpressionValidator
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFormLayout,
    QLabel,
    QLineEdit,
    QTextEdit,
    QVBoxLayout,
)

READING_STATUSES = ["Unread", "Reading", "Completed"]
DEFAULT_GENRES = [
    "Fiction", "Non-Fiction", "Science", "Technology", "Biography",
    "History", "Fantasy", "Mystery", "Self-Help", "Business", "Other",
]
DEFAULT_LANGUAGES = [
    "English", "Hindi", "Spanish", "French", "German", "Italian",
    "Portuguese", "Russian", "Chinese", "Japanese", "Arabic", "Other",
]


class AddEditBookDialog(QDialog):
    def __init__(self, parent=None, book: dict = None):
        super().__init__(parent)
        self.book = book
        self.setWindowTitle("Edit Book" if book else "Add Book")
        self.setMinimumWidth(480)

        form = QFormLayout()
        form.setSpacing(12)
        form.setLabelAlignment(Qt.AlignLeft)

        self.title_edit = QLineEdit(book["title"] if book else "")
        self.title_edit.setPlaceholderText("e.g. The Pragmatic Programmer")

        self.author_edit = QLineEdit(book["author"] if book else "")
        self.isbn_edit = QLineEdit(book["isbn"] if book else "")
        self.isbn_edit.setPlaceholderText("978-...")

        self.genre_combo = QComboBox()
        self.genre_combo.setEditable(True)
        self.genre_combo.addItems(DEFAULT_GENRES)
        if book and book.get("genre"):
            self.genre_combo.setCurrentText(book["genre"])
        else:
            self.genre_combo.setCurrentIndex(-1)
            self.genre_combo.setCurrentText("")

        self.language_combo = QComboBox()
        self.language_combo.setEditable(True)
        self.language_combo.addItems(DEFAULT_LANGUAGES)
        if book and book.get("language"):
            self.language_combo.setCurrentText(book["language"])
        else:
            self.language_combo.setCurrentText("English")  # sensible default, still editable

        self.publisher_edit = QLineEdit(book["publisher"] if book else "")

        self.purchase_date_edit = QDateEdit()
        self.purchase_date_edit.setCalendarPopup(True)
        self.purchase_date_edit.setDisplayFormat("yyyy-MM-dd")
        if book and book.get("purchase_date"):
            self.purchase_date_edit.setDate(QDate.fromString(book["purchase_date"], "yyyy-MM-dd"))
        else:
            self.purchase_date_edit.setDate(QDate.currentDate())

        self.price_spin = QDoubleSpinBox()
        self.price_spin.setPrefix("₹ ")
        self.price_spin.setMaximum(100000)
        self.price_spin.setDecimals(2)
        if book and book.get("purchase_price"):
            self.price_spin.setValue(book["purchase_price"])

        self.amazon_edit = QLineEdit(book["amazon_link"] if book else "")
        self.amazon_edit.setPlaceholderText("https://amazon.com/dp/...")

        self.status_combo = QComboBox()
        self.status_combo.addItems(READING_STATUSES)
        if book and book.get("reading_status"):
            self.status_combo.setCurrentText(book["reading_status"])

        form.addRow("Title *", self.title_edit)
        form.addRow("Author", self.author_edit)
        form.addRow("ISBN", self.isbn_edit)
        form.addRow("Genre", self.genre_combo)
        form.addRow("Language", self.language_combo)
        form.addRow("Publisher", self.publisher_edit)
        form.addRow("Purchase Date", self.purchase_date_edit)
        form.addRow("Purchase Price", self.price_spin)
        form.addRow("Amazon Link", self.amazon_edit)
        form.addRow("Reading Status", self.status_combo)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        buttons.button(QDialogButtonBox.Save).setObjectName("primaryButton")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(16)
        heading = QLabel(self.windowTitle())
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def get_data(self) -> dict:
        return {
            "title": self.title_edit.text().strip(),
            "author": self.author_edit.text().strip(),
            "isbn": self.isbn_edit.text().strip(),
            "genre": self.genre_combo.currentText().strip(),
            "language": self.language_combo.currentText().strip(),
            "publisher": self.publisher_edit.text().strip(),
            "purchase_date": self.purchase_date_edit.date().toString("yyyy-MM-dd"),
            "purchase_price": self.price_spin.value(),
            "amazon_link": self.amazon_edit.text().strip(),
            "reading_status": self.status_combo.currentText(),
        }


class AddEditLendingDialog(QDialog):
    def __init__(self, parent=None, db=None, record: dict = None):
        super().__init__(parent)
        self.db = db
        self.record = record
        self.setWindowTitle("Edit Lending Record" if record else "Lend a Book")
        self.setMinimumWidth(480)

        form = QFormLayout()
        form.setSpacing(12)
        form.setLabelAlignment(Qt.AlignLeft)

        self.book_combo = QComboBox()
        if record:
            # Editing an existing record - the book itself can't be swapped.
            self.book_combo.addItem(record["book_title"], record["book_id"])
            self.book_combo.setEnabled(False)
        else:
            for b in db.get_available_books():
                self.book_combo.addItem(b["title"], b["id"])

        self.borrower_edit = QLineEdit(record["borrower_name"] if record else "")
        self.borrower_edit.setPlaceholderText("Who is borrowing this book?")

        self.contact_edit = QLineEdit(record.get("contact_number", "") if record else "")
        self.contact_edit.setPlaceholderText("e.g. +91 98765 43210")
        # allow digits, spaces, +, -, () - permissive so any phone format works
        self.contact_edit.setValidator(
            QRegularExpressionValidator(QRegularExpression(r"[0-9+\-() ]{0,20}"))
        )

        self.date_lent_edit = QDateEdit()
        self.date_lent_edit.setCalendarPopup(True)
        self.date_lent_edit.setDisplayFormat("yyyy-MM-dd")
        self.date_lent_edit.setDate(
            QDate.fromString(record["date_lent"], "yyyy-MM-dd") if record else QDate.currentDate()
        )

        self.expected_return_edit = QDateEdit()
        self.expected_return_edit.setCalendarPopup(True)
        self.expected_return_edit.setDisplayFormat("yyyy-MM-dd")
        if record and record.get("expected_return_date"):
            self.expected_return_edit.setDate(
                QDate.fromString(record["expected_return_date"], "yyyy-MM-dd")
            )
        else:
            self.expected_return_edit.setDate(QDate.currentDate().addDays(14))

        self.notes_edit = QTextEdit(record["notes"] if record and record.get("notes") else "")
        self.notes_edit.setFixedHeight(70)
        self.notes_edit.setPlaceholderText("Optional notes…")

        form.addRow("Book *", self.book_combo)
        form.addRow("Borrower Name *", self.borrower_edit)
        form.addRow("Contact No.", self.contact_edit)
        form.addRow("Date Lent", self.date_lent_edit)
        form.addRow("Expected Return", self.expected_return_edit)
        form.addRow("Notes", self.notes_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        buttons.button(QDialogButtonBox.Save).setObjectName("primaryButton")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 20)
        layout.setSpacing(16)
        heading = QLabel(self.windowTitle())
        heading.setObjectName("dialogTitle")
        layout.addWidget(heading)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def get_data(self) -> dict:
        data = {
            "book_id": self.book_combo.currentData(),
            "borrower_name": self.borrower_edit.text().strip(),
            "contact_number": self.contact_edit.text().strip(),
            "date_lent": self.date_lent_edit.date().toString("yyyy-MM-dd"),
            "expected_return_date": self.expected_return_edit.date().toString("yyyy-MM-dd"),
            "notes": self.notes_edit.toPlainText().strip(),
        }
        if self.record:
            data["actual_return_date"] = self.record.get("actual_return_date") or ""
            data["lending_status"] = self.record.get("lending_status") or "Lent"
        else:
            data["actual_return_date"] = ""
            data["lending_status"] = "Lent"
        return data
