"""Dashboard page: KPI stat cards + genre ranking and reading-progress charts."""

from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget

from . import charts
from .widgets import Card, ChartCanvas, PageHeader, StatCard

ACCENTS = ["#7C6CF0", "#2DD4A7", "#FBBF24", "#FF7A7A"]


class DashboardPage(QWidget):
    def __init__(self, db):
        super().__init__()
        self.db = db

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(20)

        layout.addWidget(PageHeader("Dashboard", "A quick look at your library and who has your books."))

        cards_row = QHBoxLayout()
        cards_row.setSpacing(16)
        self.total_card = StatCard("📚", "Total Books", accent=ACCENTS[0])
        self.available_card = StatCard("📖", "On the Shelf", accent=ACCENTS[1])
        self.lent_card = StatCard("🤝", "Lent Out", accent=ACCENTS[2])
        self.overdue_card = StatCard("⏰", "Overdue", accent=ACCENTS[3])
        for c in (self.total_card, self.available_card, self.lent_card, self.overdue_card):
            cards_row.addWidget(c, 1)
        layout.addLayout(cards_row)

        charts_row = QHBoxLayout()
        charts_row.setSpacing(16)

        genre_card = Card("Books by Genre", "Which genres fill your shelves the most")
        self.genre_canvas = ChartCanvas(min_height=260)
        genre_card.layout.addWidget(self.genre_canvas, 1)

        reading_card = Card("Reading Progress", "How much of your collection you've read")
        self.reading_canvas = ChartCanvas(min_height=260)
        reading_card.layout.addWidget(self.reading_canvas, 1)

        charts_row.addWidget(genre_card, 3)
        charts_row.addWidget(reading_card, 2)
        layout.addLayout(charts_row, 1)

        self.refresh()

    def refresh(self):
        stats = self.db.get_dashboard_stats()
        total = stats["total"]
        self.total_card.set_value(total, "in your collection")
        self.available_card.set_value(
            stats["available"],
            f"{stats['available'] * 100 // total}% of your books" if total else "",
        )
        self.lent_card.set_value(stats["lent"], "with friends right now" if stats["lent"] else "nothing lent out")
        self.overdue_card.set_value(stats["overdue"], "need following up" if stats["overdue"] else "all good")

        # Genre ranking
        genres = self.db.get_books_by_genre()
        self.genre_canvas.play(lambda fig, p: [
            (b, f"{name}: {v} book{'s' if v != 1 else ''}")
            for b, name, v in charts.draw_hbar(
                fig, genres, color=ACCENTS[0],
                empty_message="Add your first book to see genres here",
                max_items=8, label_limit=22, progress=p)
        ])

        # Reading progress
        reading = self.db.get_reading_stats()
        order = ["Completed", "Reading", "Unread"]
        data = [(k, reading[k]) for k in order if k in reading]
        data += [(k, v) for k, v in reading.items() if k not in order]
        self.reading_canvas.play(lambda fig, p: [
            (w, f"{label}: {v} book{'s' if v != 1 else ''}")
            for w, label, v in charts.draw_donut(
                fig, data, colors=charts.STATUS_COLORS,
                empty_message="Add your first book to track reading", progress=p)
        ])
