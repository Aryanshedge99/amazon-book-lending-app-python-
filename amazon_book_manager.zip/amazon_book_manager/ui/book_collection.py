"""Book Collection page: searchable/filterable table with add/edit/delete."""

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from currency import format_inr
from .dialogs import AddEditBookDialog
from .widgets import Card, PageHeader

COLUMNS = ["Title", "Author", "Genre", "Language", "ISBN", "Publisher", "Purchased",
           "Price", "Status", "Availability"]

COLOR_AVAILABLE = QColor("#2DD4A7")
COLOR_LENT = QColor("#FF7A7A")
READING_COLORS = {
    "Unread": QColor("#8A8AA0"),
    "Reading": QColor("#FBBF24"),
    "Completed": QColor("#2DD4A7"),
}


class BookCollectionPage(QWidget):
    def __init__(self, db, on_change=None):
        super().__init__()
        self.db = db
        self.on_change = on_change
        self.rows_data = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 28, 32, 28)
        layout.setSpacing(16)

        layout.addWidget(PageHeader("Book Collection", "Search, filter and manage every book you own."))

        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Search by title, author, ISBN, publisher…")
        self.search_edit.textChanged.connect(self.refresh)

        self.genre_filter = QComboBox()
        self.genre_filter.currentTextChanged.connect(self.refresh)

        self.status_filter = QComboBox()
        self.status_filter.addItems(["All", "Available", "Lent Out"])
        self.status_filter.currentTextChanged.connect(self.refresh)

        add_btn = QPushButton("＋ Add Book")
        add_btn.setObjectName("primaryButton")
        add_btn.clicked.connect(self.add_book)

        toolbar.addWidget(self.search_edit, 2)
        toolbar.addWidget(self.genre_filter, 1)
        toolbar.addWidget(self.status_filter, 1)
        toolbar.addStretch()
        toolbar.addWidget(add_btn)
        layout.addLayout(toolbar)

        card = Card()
        self.count_lbl = QLabel("")
        self.count_lbl.setObjectName("resultCount")
        card.layout.addWidget(self.count_lbl)
        self.table = QTableWidget(0, len(COLUMNS))
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(False)
        self.table.setFocusPolicy(Qt.NoFocus)
        self.table.verticalHeader().setDefaultSectionSize(44)
        self.table.horizontalHeader().setHighlightSections(False)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.table.setToolTip("Double-click a row to edit")
        self.table.setHorizontalHeaderLabels(COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.doubleClicked.connect(self.edit_selected)
        card.layout.addWidget(self.table)
        layout.addWidget(card, 1)

        actions = QHBoxLayout()
        edit_btn = QPushButton("Edit")
        edit_btn.clicked.connect(self.edit_selected)
        del_btn = QPushButton("Delete")
        del_btn.setObjectName("dangerButton")
        del_btn.clicked.connect(self.delete_selected)
        link_btn = QPushButton("Open Amazon Link")
        link_btn.clicked.connect(self.open_link)
        actions.addWidget(edit_btn)
        actions.addWidget(del_btn)
        actions.addWidget(link_btn)
        actions.addStretch()
        layout.addLayout(actions)

        self.refresh()

    def refresh(self):
        genres = ["All"] + self.db.get_genres()
        current = self.genre_filter.currentText()
        self.genre_filter.blockSignals(True)
        self.genre_filter.clear()
        self.genre_filter.addItems(genres)
        if current in genres:
            self.genre_filter.setCurrentText(current)
        self.genre_filter.blockSignals(False)

        rows = self.db.get_books(
            search=self.search_edit.text().strip(),
            genre=self.genre_filter.currentText() or "All",
            status=self.status_filter.currentText(),
        )
        self.rows_data = rows
        self.count_lbl.setText(
            f"{len(rows)} book{'s' if len(rows) != 1 else ''}"
            + ("  ·  no matches, try a different search" if not rows else "  ·  double-click a row to edit")
        )
        self.table.setRowCount(len(rows))
        for r, book in enumerate(rows):
            values = [
                book["title"],
                book["author"] or "—",
                book["genre"] or "—",
                book.get("language") or "—",
                book["isbn"] or "—",
                book["publisher"] or "—",
                book["purchase_date"] or "—",
                format_inr(book["purchase_price"]) if book["purchase_price"] else "—",
                book["reading_status"] or "—",
                book["availability"],
            ]
            for c, val in enumerate(values):
                item = QTableWidgetItem(str(val))
                if c == 9:
                    item.setText("●  " + str(val))
                    item.setForeground(COLOR_LENT if val == "Lent Out" else COLOR_AVAILABLE)
                elif c == 8:
                    item.setText("●  " + str(val))
                    item.setForeground(READING_COLORS.get(val, QColor("#E8E8F2")))
                elif c in (3, 4, 5, 6):
                    item.setForeground(QColor("#A2A2BA"))
                self.table.setItem(r, c, item)
            self.table.item(r, 0).setData(Qt.UserRole, book["id"])

    def selected_book(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.rows_data):
            return None
        return self.rows_data[row]

    def add_book(self):
        dlg = AddEditBookDialog(self)
        if dlg.exec():
            data = dlg.get_data()
            if not data["title"]:
                QMessageBox.warning(self, "Missing Title", "Book title is required.")
                return
            self.db.add_book(data)
            self.refresh()
            if self.on_change:
                self.on_change()

    def edit_selected(self):
        book = self.selected_book()
        if not book:
            return
        dlg = AddEditBookDialog(self, book=book)
        if dlg.exec():
            data = dlg.get_data()
            if not data["title"]:
                QMessageBox.warning(self, "Missing Title", "Book title is required.")
                return
            self.db.update_book(book["id"], data)
            self.refresh()
            if self.on_change:
                self.on_change()

    def delete_selected(self):
        book = self.selected_book()
        if not book:
            return
        if book.get("active_lending_id"):
            QMessageBox.warning(
                self, "Cannot Delete",
                "This book is currently lent out. Mark it as returned before deleting.",
            )
            return
        confirm = QMessageBox.question(
            self, "Delete Book", f"Delete '{book['title']}'? This cannot be undone."
        )
        if confirm == QMessageBox.Yes:
            self.db.delete_book(book["id"])
            self.refresh()
            if self.on_change:
                self.on_change()

    def open_link(self):
        book = self.selected_book()
        if book and book.get("amazon_link"):
            QDesktopServices.openUrl(QUrl(book["amazon_link"]))
        elif book:
            QMessageBox.information(self, "No Link", "This book has no Amazon link saved.")
