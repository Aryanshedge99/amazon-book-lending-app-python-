"""
SQLite data-access layer for the Bookshelf app.
All book / lending CRUD operations and analytics queries live here so the UI
layer never touches SQL directly.
"""

import os
import sqlite3
from datetime import date

DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "library.db")


class Database:
    def __init__(self, db_path: str = DB_FILE):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self._create_tables()

    def _create_tables(self):
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT,
                isbn TEXT,
                genre TEXT,
                language TEXT,
                publisher TEXT,
                purchase_date TEXT,
                purchase_price REAL,
                amazon_link TEXT,
                reading_status TEXT DEFAULT 'Unread',
                added_date TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS lending (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                book_id INTEGER NOT NULL,
                borrower_name TEXT NOT NULL,
                contact_number TEXT,
                date_lent TEXT NOT NULL,
                expected_return_date TEXT,
                actual_return_date TEXT,
                lending_status TEXT DEFAULT 'Lent',
                notes TEXT,
                FOREIGN KEY (book_id) REFERENCES books (id) ON DELETE CASCADE
            );
            """
        )
        self.conn.commit()
        self._migrate()

    def _migrate(self):
        """Add columns that didn't exist in earlier versions of the database
        without wiping any existing data."""
        lending_cols = [r[1] for r in self.conn.execute("PRAGMA table_info(lending)").fetchall()]
        if "contact_number" not in lending_cols:
            self.conn.execute("ALTER TABLE lending ADD COLUMN contact_number TEXT")

        book_cols = [r[1] for r in self.conn.execute("PRAGMA table_info(books)").fetchall()]
        if "language" not in book_cols:
            self.conn.execute("ALTER TABLE books ADD COLUMN language TEXT")

        self.conn.commit()

    # ------------------------------------------------------------------ #
    # Books
    # ------------------------------------------------------------------ #
    def add_book(self, data: dict) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO books (title, author, isbn, genre, language, publisher, purchase_date,
                                purchase_price, amazon_link, reading_status)
            VALUES (:title, :author, :isbn, :genre, :language, :publisher, :purchase_date,
                    :purchase_price, :amazon_link, :reading_status)
            """,
            data,
        )
        self.conn.commit()
        return cur.lastrowid

    def update_book(self, book_id: int, data: dict):
        payload = dict(data)
        payload["id"] = book_id
        self.conn.execute(
            """
            UPDATE books SET title=:title, author=:author, isbn=:isbn, genre=:genre,
                language=:language, publisher=:publisher, purchase_date=:purchase_date,
                purchase_price=:purchase_price, amazon_link=:amazon_link,
                reading_status=:reading_status
            WHERE id=:id
            """,
            payload,
        )
        self.conn.commit()

    def delete_book(self, book_id: int):
        self.conn.execute("DELETE FROM books WHERE id = ?", (book_id,))
        self.conn.commit()

    def get_book(self, book_id: int):
        row = self.conn.execute("SELECT * FROM books WHERE id = ?", (book_id,)).fetchone()
        return dict(row) if row else None

    def get_books(self, search: str = "", genre: str = "All", status: str = "All"):
        self.refresh_overdue()
        query = """
            SELECT b.*,
                (SELECT l.id FROM lending l WHERE l.book_id = b.id
                    AND l.lending_status IN ('Lent', 'Overdue') LIMIT 1) AS active_lending_id,
                (SELECT l.borrower_name FROM lending l WHERE l.book_id = b.id
                    AND l.lending_status IN ('Lent', 'Overdue') LIMIT 1) AS borrower
            FROM books b
            WHERE 1 = 1
        """
        params = []
        if search:
            query += " AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ? OR b.publisher LIKE ?)"
            like = f"%{search}%"
            params += [like, like, like, like]
        if genre != "All":
            query += " AND b.genre = ?"
            params.append(genre)
        query += " ORDER BY b.title COLLATE NOCASE"

        rows = [dict(r) for r in self.conn.execute(query, params).fetchall()]
        for r in rows:
            r["availability"] = "Lent Out" if r["active_lending_id"] else "Available"
        if status != "All":
            rows = [r for r in rows if r["availability"] == status]
        return rows

    def get_genres(self):
        rows = self.conn.execute(
            "SELECT DISTINCT genre FROM books WHERE genre IS NOT NULL AND genre != '' ORDER BY genre"
        ).fetchall()
        return [r[0] for r in rows]

    # ------------------------------------------------------------------ #
    # Lending
    # ------------------------------------------------------------------ #
    def refresh_overdue(self):
        """Flip any 'Lent' record past its expected return date to 'Overdue'."""
        today = date.today().isoformat()
        self.conn.execute(
            """
            UPDATE lending SET lending_status = 'Overdue'
            WHERE lending_status = 'Lent'
              AND expected_return_date IS NOT NULL AND expected_return_date != ''
              AND expected_return_date < ?
              AND (actual_return_date IS NULL OR actual_return_date = '')
            """,
            (today,),
        )
        self.conn.commit()

    def add_lending(self, data: dict) -> int:
        cur = self.conn.execute(
            """
            INSERT INTO lending (book_id, borrower_name, contact_number, date_lent,
                                  expected_return_date, actual_return_date, lending_status, notes)
            VALUES (:book_id, :borrower_name, :contact_number, :date_lent,
                    :expected_return_date, :actual_return_date, :lending_status, :notes)
            """,
            data,
        )
        self.conn.commit()
        return cur.lastrowid

    def update_lending(self, lending_id: int, data: dict):
        payload = dict(data)
        payload["id"] = lending_id
        self.conn.execute(
            """
            UPDATE lending SET book_id=:book_id, borrower_name=:borrower_name,
                contact_number=:contact_number, date_lent=:date_lent,
                expected_return_date=:expected_return_date,
                actual_return_date=:actual_return_date, lending_status=:lending_status,
                notes=:notes
            WHERE id=:id
            """,
            payload,
        )
        self.conn.commit()

    def delete_lending(self, lending_id: int):
        self.conn.execute("DELETE FROM lending WHERE id = ?", (lending_id,))
        self.conn.commit()

    def mark_returned(self, lending_id: int, return_date: str = None):
        return_date = return_date or date.today().isoformat()
        self.conn.execute(
            "UPDATE lending SET actual_return_date = ?, lending_status = 'Returned' WHERE id = ?",
            (return_date, lending_id),
        )
        self.conn.commit()

    def get_lending_records(self, search: str = "", status: str = "All"):
        self.refresh_overdue()
        query = """
            SELECT l.*, b.title AS book_title
            FROM lending l
            JOIN books b ON l.book_id = b.id
            WHERE 1 = 1
        """
        params = []
        if search:
            query += " AND (l.borrower_name LIKE ? OR b.title LIKE ?)"
            like = f"%{search}%"
            params += [like, like]
        if status != "All":
            query += " AND l.lending_status = ?"
            params.append(status)
        query += " ORDER BY l.date_lent DESC"
        return [dict(r) for r in self.conn.execute(query, params).fetchall()]

    def get_available_books(self):
        rows = self.conn.execute(
            """
            SELECT b.id, b.title FROM books b
            WHERE b.id NOT IN (
                SELECT book_id FROM lending WHERE lending_status IN ('Lent', 'Overdue')
            )
            ORDER BY b.title COLLATE NOCASE
            """
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ #
    # Dashboard / Analytics
    # ------------------------------------------------------------------ #
    def get_dashboard_stats(self):
        self.refresh_overdue()
        total = self.conn.execute("SELECT COUNT(*) FROM books").fetchone()[0]
        lent = self.conn.execute(
            "SELECT COUNT(*) FROM lending WHERE lending_status IN ('Lent', 'Overdue')"
        ).fetchone()[0]
        overdue = self.conn.execute(
            "SELECT COUNT(*) FROM lending WHERE lending_status = 'Overdue'"
        ).fetchone()[0]
        return {"total": total, "available": total - lent, "lent": lent, "overdue": overdue}

    def get_books_by_genre(self):
        rows = self.conn.execute(
            """
            SELECT COALESCE(NULLIF(genre, ''), 'Uncategorized') AS genre, COUNT(*) AS c
            FROM books GROUP BY genre ORDER BY c DESC
            """
        ).fetchall()
        return [(r[0], r[1]) for r in rows]

    def get_most_lent_books(self, limit: int = 10):
        rows = self.conn.execute(
            """
            SELECT b.title, COUNT(*) AS c FROM lending l
            JOIN books b ON l.book_id = b.id
            GROUP BY l.book_id ORDER BY c DESC LIMIT ?
            """,
            (limit,),
        ).fetchall()
        return [(r[0], r[1]) for r in rows]

    def get_monthly_purchases(self, months: int = 12):
        rows = self.conn.execute(
            """
            SELECT strftime('%Y-%m', purchase_date) AS ym, COUNT(*) AS c,
                   COALESCE(SUM(purchase_price), 0) AS total
            FROM books
            WHERE purchase_date IS NOT NULL AND purchase_date != ''
            GROUP BY ym ORDER BY ym DESC LIMIT ?
            """,
            (months,),
        ).fetchall()
        return list(reversed([(r[0], r[1], r[2]) for r in rows]))

    def get_reading_stats(self):
        rows = self.conn.execute(
            """
            SELECT COALESCE(NULLIF(reading_status, ''), 'Unread') AS s, COUNT(*) AS c
            FROM books GROUP BY s
            """
        ).fetchall()
        return {r[0]: r[1] for r in rows}

    def get_spending_summary(self):
        row = self.conn.execute(
            """
            SELECT COALESCE(SUM(purchase_price), 0), COUNT(purchase_price),
                   COALESCE(AVG(NULLIF(purchase_price, 0)), 0)
            FROM books WHERE purchase_price IS NOT NULL AND purchase_price > 0
            """
        ).fetchone()
        return {"total": row[0], "priced_books": row[1], "average": row[2]}

    def close(self):
        self.conn.close()
